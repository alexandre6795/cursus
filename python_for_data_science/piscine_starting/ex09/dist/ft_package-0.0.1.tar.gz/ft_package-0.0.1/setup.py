from setuptools import setup, find_packages
setup(
    name="ft_package",
    version="0.0.1",
    description="A sample test",
    url=": https://github.com/aherrman/ft_package",
    author="aherrman",
    author_email="aherrman.42mulhouse.com",
    license="MIT",
    packages=find_packages(),
    install_requires="",
    classifiers="",
    entry_points="",
)